<?php
//include('custom/pages/home/featured/control.php');
//include('custom/pages/home/promo/control.php');
?>