<?php
include("custom/products/add/multiple_insert_product/control.php");
?>