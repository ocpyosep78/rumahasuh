Need change in htaccess

PHPExcel