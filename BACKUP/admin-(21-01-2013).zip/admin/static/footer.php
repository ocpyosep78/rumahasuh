<div class="footer">
    <div class="container">
        &copy; 2013 Antikode. For any enquiries, <a href="mailto:info@antikode.com">info@antikode.com</a>.
  </div>
</div>