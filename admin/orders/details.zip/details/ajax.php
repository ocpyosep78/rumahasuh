<?
// orders/details/ajax.php
?>