<?php
/* --- CONTROL --- */

/*
|--------------------|
|      SORTING       |
|--------------------|
*/

$equal_search    = array('order_payment_method', 'payment_status', 'fulfillment_status', 'order_date');
$default_sort_by = "order_id DESC";

$pgdata = page_init($equal_search,$default_sort_by); // static/general.php

$page             = $pgdata['page'];
$query_per_page   = $pgdata['query_per_page'];
$sort_by          = $pgdata['sort_by'];
$first_record     = $pgdata['first_record'];
$search_parameter = $pgdata['search_parameter'];
$search_value     = $pgdata['search_value'];
$search_query     = $pgdata['search_query'];
$search           = $pgdata['search'];


$full_order  = fullOrderIndex($search_query, $sort_by, $first_record ,$query_per_page);
$total_query = $full_order['total_query'];
$total_page  = $full_order['total_page']; // RESULT

// CALL FUNCTION
$listing_order = orderIndex($search_query, $sort_by, $first_record, $query_per_page);


// HANDLING ARROW SORTING

if($_REQUEST['srt'] == "order_number DESC"){
   $arr_order_number = "<span class=\"sort-arrow-up\"></span>";
}else if($_REQUEST['srt'] == "order_number"){
   $arr_order_number = "<span class=\"sort-arrow-down\"></span>";
			   
}else if($_REQUEST['srt'] == "order_date DESC"){
   $arr_order_date = "<span class=\"sort-arrow-up\"></span>";
}else if($_REQUEST['srt'] == "order_date"){
   $arr_order_date = "<span class=\"sort-arrow-down\"></span>";
									  
}else if($_REQUEST['srt'] == "order_confirm_name DESC"){
   $arr_confirm_name = "<span class=\"sort-arrow-up\"></span>";
}else if($_REQUEST['srt'] == "order_confirm_name"){
   $arr_confirm_name = "<span class=\"sort-arrow-down\"></span>";
									  
}else if($_REQUEST['srt'] == "order_confirm_bank DESC"){
   $arr_confirm_bank = "<span class=\"sort-arrow-up\"></span>";
}else if($_REQUEST['srt'] == "order_confirm_bank"){
   $arr_confirm_bank = "<span class=\"sort-arrow-down\"></span>";
									  
}else if($_REQUEST['srt'] == "order_confirm_amount DESC"){
   $arr_confirm_amount = "<span class=\"sort-arrow-up\"></span>";
}else if($_REQUEST['srt'] == "order_confirm_name"){
   $arr_confirm_amount = "<span class=\"sort-arrow-down\"></span>";
									  
}else if($_REQUEST['srt'] == "payment_status DESC"){
   $arr_payment_status = "<span class=\"sort-arrow-up\"></span>";
}else if($_REQUEST['srt'] == "payment_status"){
   $arr_payment_status = "<span class=\"sort-arrow-down\"></span>";
									  
}else if($_REQUEST['srt'] == "fulfillment_status DESC"){
   $arr_fulfillment_status = "<span class=\"sort-arrow-up\"></span>";
}else if($_REQUEST['srt'] == "fulfillment_status"){
   $arr_fulfillment_status = "<span class=\"sort-arrow-down\"></span>";
}


// STORED VALUE
echo "<input type=\"hidden\" name=\"url\" id=\"url\" class=\"hidden\" value=\"http://".$_SERVER['HTTP_HOST'].get_dirname($_SERVER['PHP_SELF'])."/order-view\">\n";
echo "<input type=\"hidden\" name=\"url\" id=\"alternate-url\" class=\"hidden\" value=\"http://".$_SERVER['HTTP_HOST'].get_dirname($_SERVER['PHP_SELF'])."/order\">\n"; // Reset option
echo "<input type=\"hidden\" name=\"page\" id=\"page\" class=\"hidden\" value=\"".$page."\" /> \n";
echo "<input type=\"hidden\" name=\"query_per_page\" id=\"query_per_page\" class=\"hidden\" value=\"".$query_per_page."\" /> \n";
echo "<input type=\"hidden\" name=\"total_page\" id=\"total_page\" class=\"hidden\" value=\"".$total_page."\" /> \n";
echo "<input type=\"hidden\" name=\"sort_by\" id=\"sort_by\" class=\"hidden\" value=\"".$sort_by."\" /> \n";
echo "<input type=\"hidden\" name=\"search\" id=\"search\" class=\"hidden\" value=\"".$search_parameter."-".$search_value."\" /> \n";


function edit_mode(){

   echo '<div class="info-header">';
   echo '   <div class="content">';
   
   if($_POST['btn-order-detail'] == "Cancel"){   
      echo "   Edit Order Mode <br />";
   }else if($_POST['btn-order-detail'] == "Save Changes"){   
      echo "Data has successfully updated <br />";  
   }else if($_POST['btn-order-detail'] == "Mark as Paid"){
      echo "   An email has been sent to demo@antikode.com <br />";
   }else{   
      echo "   Edit Order Mode <br />"; 
   }
   
   echo '   </div>';
   echo '</div>';
	  
}


// Handling css for payment_status
function payment_status_flag($flag_payment_status){
   
   if($flag_payment_status == "Paid"){
      $payment_status = "stat green";
   }else if($flag_payment_status == "Confirmed"){
      $payment_status = "stat yellow";
   }else if($flag_payment_status == "Unpaid"){
	  $payment_status = "stat red";
   }
   
   return $payment_status;
   
}

// Handling css for fulfillment_status
function fulfillment_status_flag($flag_fulfillment_status){

   if($flag_fulfillment_status == "Unfulfilled"){
      $fulfillment_status = "stat grey";
   }else if($flag_fulfillment_status == "In Process" || $flag_fulfillment_status == "Partial"){
      $fulfillment_status = "stat yellow";
   }else if($flag_fulfillment_status == "Delivered"){
      $fulfillment_status = "stat green";
   }else if ($flag_fulfillment_status == "Cancelled" || $flag_fulfillment_status == "Expired"){
      $fulfillment_status = "stat red";
   }
   
   return $fulfillment_status;
   
}

// Capitalizing Bank Name
function capitaling_bank_name($flag_bank_name){
   
   if (strlen($flag_bank_name) > 4){
      $order_confirm_bank = ucwords(strtolower($flag_bank_name));
   }else{
      $order_confirm_bank = strtoupper($flag_bank_name);
   }
   
   return $order_confirm_bank;
   
}



/* BUTTON HANDLER */

if($_POST['index-order'] == "GO" ){
	
   $order_id    = $_POST['checkbox'];      // Get order_id
   $post_action = $_POST['option-action']; // Action : Change or Delete
   
   if($post_action == "delete"){
      
	  foreach($order_id as $order_id){
		 $sql    = "DELETE FROM `tbl_order` WHERE `order_id` = '$order_id'";
		 $query  = mysql_query($sql, $conn);
		 
		 delete_user_purchase($order_id);
		 delete_order_item($order_id);
	  }
   
   }else{
	  $post_status = $_POST['option-status']; // Option : Unpaid, Paid, Unfulfilled, In Process, Delivered, Cancelled, Expired
	  
	  if($post_status == "Unpaid"){
		 
		 foreach($order_id as $order_id){
			$sql     = "UPDATE `tbl_order` SET `payment_status` = '$post_status' WHERE `order_id` = '$order_id'";
			$query   = mysql_query($sql, $conn);
		 }
      
      }else if($post_status == "Confirmed"){
	     
		 foreach($order_id as $order_id){
		    $sql     = "UPDATE `tbl_order` SET `payment_status` = '$post_status' WHERE `order_id` = '$order_id'";
			$query   = mysql_query($sql, $conn);
		 }
	  
	  }else if($post_status == "Paid"){
		 
		 foreach($order_id as $order_id){
		    $sql     = "UPDATE `tbl_order` SET `payment_status` = '$post_status', `fulfillment_status`  = 'In Process' WHERE `order_id` = '$order_id'";
		    $query   = mysql_query($sql, $conn);
		 }
	        
      }else if ($post_status == "Unfulfilled" || $post_status == "Expired" || $post_status == "Cancelled"){
		 
		 foreach($order_id as $order_id){
		    $sql     = "UPDATE `tbl_order` SET `fulfillment_status` = '$post_status' WHERE `order_id` = '$order_id'";
			$query   = mysql_query($sql, $conn);
		 }
			
      }else if ($post_status == "In Process" || $post_status == "Delivered"){
		 
		 foreach($order_id as $order_id){
		    $sql     = "UPDATE `tbl_order` SET `payment_status` = 'Paid', `fulfillment_status` = '$post_status' WHERE `order_id` = '$order_id'";
			$query   = mysql_query($sql, $conn);
		 }
			
      }
	  
   }

}




/* -- BUTTON RESET -- */
if(empty($search_parameter)){
   $reset = "hidden";
}else{
   $reset = "";
}

function order_disabling_search($variabel, $post_src){
   
   if($variabel == "$post_src"){ 
      echo "value=\"".str_replace('\\', '/', $_REQUEST['srcval'])."\"";
   }else if(!empty($variabel)){ 
      echo "disabled";
   }

}
?>











<?php
/*
==============================
|							 |
|        DETAIL ORDER 	     |
|							 |
==============================

*/
// Set date
$set_fulfilment_date = date("Y-m-d H:i:s");



$order_number = $_REQUEST['oid'];

$get_order_id = get_order_detail_by_number($order_number);
$order_detail = get_order_detail($get_order_id['order_id']);
$order_item = order_item($order_detail['order_id']);


// Get payment_status
function control_get_payment_status($pay_stat){
   
   if($pay_stat == "Unpaid"){
      $flag_payment_status = "stat red";
   }else if($pay_stat == "Confirmed"){
      $flag_payment_status = "stat yellow";
   }else if($pay_stat == "Paid"){
      $flag_payment_status = "stat green";
   }
   
   return $flag_payment_status;
   
}

// Get fulfillment_status
function control_fulfillment_status($ful_stat){

   if($ful_stat == "Unfulfilled"){
      $flag_fulfillment_status = "stat grey";
   }else if($ful_stat == "In Process" || $ful_stat == "Partial"){
      $flag_fulfillment_status = "stat yellow";
   }else if($ful_stat == "Cancelled" || $ful_stat == "Expired"){
      $flag_fulfillment_status = "stat red";
   }else if($ful_stat == "Delivered"){
      $flag_fulfillment_status = "stat green";
   }
   
   return $flag_fulfillment_status;
}

$order_number = $_REQUEST['oid'];

// CALL FUNCTION
$detail = detail_order($order_number);
$info   = get_info();


if(isset($_POST['btn-order-detail'])){

   if($_POST['btn-order-detail'] == "Mark as Paid"){
      db_update_mark_as_paid($order_detail['order_id']);
	  
   }else if($_POST['btn-order-detail'] == "Save Changes"){

	  $one   = $_POST['order_confirm_bank'];
	  $two   = $_POST['order_confirm_name'];
	  $number = $_POST['order_confirm_amount'];
	  $four  = $order_detail['order_id'];
	  
	  $ten    = $_POST['item_quantity'];
	  $eleven = $_POST['item_id_quantity'];
	  
	  update_order_detail_1($one,$two,$number,$four);
	  update_order_detail_2($ten,$eleven);
   }
   
}

if(isset($_POST['btn-order-detailing'])){

   if($_POST['btn-order-detailing'] == "Mark as Paid"){
      db_update_mark_as_paid($detail['order_id']);
	  
	  if($detail['payment_status'] == "Confirmed"){
	  //send mail
	  $name      = $general['website_title']; 
	  $email     = $info['email']; 
	  $recipient = $detail['user_email']; 
	  $mail_body = '<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" style="overflow: hidden; background: #000">
    <tbody>
        <tr>
          <td>
            <table width="600" border="0" cellspacing="0" cellpadding="0" align="center" style="overflow: hidden; background: #000">
              <tr>
                <td style="padding-left: 15px; padding-top: 10px; padding-bottom: 10px">
                  <img src="aa" height="50">
                </td>
              </tr>
            </table>
          </td>
        </tr>
    </tbody>
  </table>
  <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" style="overflow: hidden; background: #f0f0f0; border-bottom: 1px solid #e0e0e0">
    <tbody>
        <tr>
          <td>
            <table width="600" border="0" cellspacing="0" cellpadding="0" align="center">
              <tr>
                <td>
                  <td style="font-size: 12px; color: #999; padding-left: 15px; text-align: left;">
                    <span style="font-weight: 100">Order no.</span> <i style="font-size: 14px; color: #333">'.$order_number.'</i>
                  </td>
                  <td style="font-size: 12px; color: #fff; padding: 10px 15px; text-align: right">
                    <span style="line-height: 18px; color: #999"><b style="color: #39b54a">PAYMENT VERIFIED</b> </span>
                  </td>
                </td>
              </tr>
            </table>
          </td>
        </tr>
    </tbody>
  </table>
  <table width="600" border="0" cellspacing="0" cellpadding="0" align="center" style="font-size:12px; overflow: hidden; background: #fff; line-height: 20px">
    <tbody>
      <tr>
        <td width="600" bgcolor="#fff" style="padding: 25px">
          Dear '.$detail['user_fullname'].',<br>
          <br>
          We have verified your payment for order number <b>'.$order_number.'</b>. We are currently processing your order and will be delivered using <b>'.$detail['shipping_method'].'</b> to:<br>
          <br>
          <b>'.$detail['order_shipping_first_name'].' '.$detail['order_shipping_last_name'].'</b><br>
          '.$detail['order_billing_phone'].'<br>
          '.$detail['order_shipping_address'].'<br>
          '.$detail['order_shipping_province'].'<br>
          '.$detail['order_shipping_country'].'<br>
          <br>
          Once the order has been delivered, we will send another email notifying you about the delivery details.<br>
          <br>
          If you believe there is an error regarding the information stored. Please contact us through email at <a style="color:#0383ae" href="'.$info['email'].'">'.$info['email'].'</a>. Thank you!
        </td>
      </tr>
    </tbody>
  </table>





  <table width="600" border="0" cellspacing="0" cellpadding="0" align="center" style="font-size:11px; color: #999; margin-top:15px">
    <tbody>
      <tr>
        <td style="padding-left:20px; padding-right:20px">
          © 2013 Website Name. Powered by <a style="color: #666; text-decoration: none" href="http://www.antikode.com">Antikode</a>. <br><br>
        </td>
      </tr>
    </tbody>
  </table>';
  
  	  $subject   = "[".$general['website_title']."] ".$order_number." Payment Verified"; 
  	  $headers   = "Content-Type: text/html; charset=ISO-8859-1\r\n".
      $headers  .= "From: ".$general['website_title']." <" .$info['email']. ">\r\n"; //optional headerfields
  
      mail($recipient, $subject, $mail_body, $headers);
	  }
   }
   /*
   else if($_POST['btn-order-detail'] == "Save Changes"){

	  $one   = $_POST['order_confirm_bank'];
	  $two   = $_POST['order_confirm_name'];
	  $three = $_POST['order_confirm_amount'];
	  $four  = $order_detail['order_id'];
	  
	  $ten    = $_POST['item_quantity'];
	  $eleven = $_POST['item_id_quantity'];
	  
	  update_order_detail_1($one,$two,$three,$four);
	  update_order_detail_2($ten,$eleven);
   }
   */
   
}

/* VALIDATION FRO BUTTON DELIVER ITEM */

if(isset($_POST['deliver-validation'])){
   
   if($_POST['deliver-validation'] == "validation"){
      $_SESSION['alert'] = "error";
	  $_SESSION['msg']   = "Can't deliver item because this order must be paid first";
   }
   
}

/* DML SHIPPING NUMBER */
if(isset($_POST['btn-order-confirm'])){
   
   if($_POST['btn-order-confirm'] == "Confirm"){ 
	  $order_item   = $_POST['backup_item_id'];
	  $current_date = current_date_sql();
	  
	  foreach($order_item as $order_item){
	     // DEFINED VARIABLE
	     $service          = $_POST['shipping-service'];
	     $order_id         = $_POST['hidden_order_id'];
	     $shipping_number  = $_POST['order_shipping_number'];
	     $fulfillment_date = $current_date;
	     $notify           = $_POST['notify-deliver'];
	     $user_email       = $detail['user_email'];
		 
         updateShippingNumber($order_id, $order_item, $shipping_number, $fulfillment_date, $service);
	  }
	  
	  updateFulfillment_status($order_id, 'Delivered');
	  
	  if(!empty($notify)){
		  
	     // SEND MAIL TO CUSTOMER
		 $updated_detail = detail_order($order_number);
	  
	  if($detail['payment_status'] == "Paid"){
	  //send mail
	  $name      = $general['website_title']; 
	  $email     = $info['email']; 
	  $recipient = $detail['user_email']; 
	  $mail_body = '<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" style="overflow: hidden; background: #000">
    <tbody>
        <tr>
          <td>
            <table width="600" border="0" cellspacing="0" cellpadding="0" align="center" style="overflow: hidden; background: #000">
              <tr>
                <td style="padding-left: 15px; padding-top: 10px; padding-bottom: 10px">
                  <img src="aa" height="50">
                </td>
              </tr>
            </table>
          </td>
        </tr>
    </tbody>
  </table>
  <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" style="overflow: hidden; background: #f0f0f0; border-bottom: 1px solid #e0e0e0">
    <tbody>
        <tr>
          <td>
            <table width="600" border="0" cellspacing="0" cellpadding="0" align="center">
              <tr>
                <td>
                  <td style="font-size: 12px; color: #999; padding-left: 15px; text-align: left;">
                    <span style="font-weight: 100">Order no.</span> <i style="font-size: 14px; color: #333">'.$order_number.'</i>
                  </td>
                  <td style="font-size: 12px; color: #fff; padding: 10px 15px; text-align: right">
                    <span style="line-height: 18px; color: #999"><b style="color: #39b54a">DELIVERED</b> </span>
                  </td>
                </td>
              </tr>
            </table>
          </td>
        </tr>
    </tbody>
  </table>
  <table width="600" border="0" cellspacing="0" cellpadding="0" align="center" style="font-size:12px; overflow: hidden; background: #fff; line-height: 20px">
    <tbody>
      <tr>
        <td width="600" bgcolor="#fff" style="padding: 25px">
          Dear '.$detail['user_fullname'].',<br>
          <br>
          Your order <b>'.$order_number.'</b> has been delivered to your shipping address with the following details:<br>
          <br>
          <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#f6f6f6" style="font-size: 12px">
            <tr>
              <td>
                <b>Courier</b> '.$detail['shipping_method'].'<br>';
				
				function trim_shipping_number($num){
				   $first  = substr($num,0,1);
				   $second = substr($num,1,5);
				   $last   = substr($num,6,5);
				   
				   $return = $first.' '.$second.' '.$last;
				   
				   return $return;
				}
				
				$mail_body .='
                <b>Delivery No.</b> '.trim_shipping_number($updated_detail['shipping_number']).'<br>
              </td>
            </tr>
          </table>
          <br>
          For order tracking, please go to <a style="color: #0383ae" href="http://www.jne.co.id">www.jne.co.id</a> and put your delivery number.<br>
          <br>
          Remember that you can always see your order history by visiting <a style="color: #0383ae" href="'.$prefix_url.'../my-account/'.$detail['user_alias'].'">My Account</a> on our web store. Thank you for shopping with Shop Name.
        </td>
      </tr>
      <tr>
        <td>
          <table border="0" cellspacing="0" cellpadding="0" style="margin-left: 15px; margin-right: 15px; padding-bottom: 15px; border: 1px solid #e0e0e0">
            <tr>
              <td>
                <table border="0" cellspacing="0" cellpadding="0" style="margin-bottom: 10px; font-size: 14px; text-align: center">
                  <tr>
                    <td width="15"></td>
                      <td width="540" style="padding-top: 13px; padding-bottom: 13px; border-bottom: 1px solid #e0e0e0; font-weight: 100">
                        Sales Receipt
                      </td>
                    <td width="15"></td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td>
                <table border="0" cellspacing="0" cellpadding="0" style="margin-bottom: 20px; margin-top: 10px; font-size: 11px">
                  <td width="310" style="padding-left: 20px;">
                    <b>Shipping Address</b><br>
					'.$detail['order_shipping_first_name'].' '.$detail['order_shipping_last_name'].'</b><br>
					'.$detail['order_billing_phone'].'<br>
					'.$detail['order_shipping_address'].'<br>
					'.$detail['order_shipping_province'].'<br>
					'.$detail['order_shipping_country'].'<br>
                  </td>
                  <td width="300" valign="top">
                    <b>Order Date</b> '.date('j/m/Y',strtotime($detail['order_date'])).'<br>
                    <b>Order No.</b> '.$order_number.'<br>
                    <b>Receipt Date</b> '.date('j/m/Y',strtotime($detail['fulfillment_date'])).'<br>
                    <b>Payment Method</b> Bank Transfer via '.$updated_detail['order_payment_method'].'<br>
                    <b>Shipping Method</b> '.$detail['services'].'<br>
                  </td>
                </table>
              </td>
            </tr>
            <tr>
              <td>
                <table width="540" border="0" cellspacing="0" cellpadding="0" align="center" style="font-size: 11px; border:">
                  <thead>
                    <tr style="text-align: left;">
                      <th style="border-top: 1px solid #ccc; border-bottom: 1px solid #ccc; padding-left: 5px" width="345">Items</th>
                      <th style="border-top: 1px solid #ccc; border-bottom: 1px solid #ccc;" width="120">Price</th>
                      <th style="border-top: 1px solid #ccc; border-bottom: 1px solid #ccc; text-align: center" width="60">Qty.</th>
                      <th style="border-top: 1px solid #ccc; border-bottom: 1px solid #ccc; padding-right: 5px; text-align: right" width="115">Total</th>
                    </tr>
                  </thead>
                  <tbody style="line-height: 18px">
                    <tr>
                      <td style="border-bottom: 1px solid #ccc; padding: 5px">
                        <table border="0" cellspacing="0" cellpadding="0">
                          <tr><td><b>Product Name</b></td></tr>
                          <tr><td>Color</td></tr>
                          <tr><td>Size</td></tr>
                        </table>
                      </td>
                      <td style="border-bottom: 1px solid #ccc;">IDR 100.000</td>
                      <td style="border-bottom: 1px solid #ccc; text-align: center">2</td>
                      <td style="border-bottom: 1px solid #ccc; text-align: right; padding-right: 5px">IDR 200.000</td>
                    </tr>
                    <tr>
                      <td style="border-bottom: 1px solid #ccc; padding: 5px">
                        <table border="0" cellspacing="0" cellpadding="0">
                          <tr><td><b>Product Name</b></td></tr>
                          <tr><td>Color</td></tr>
                          <tr><td>Size</td></tr>
                        </table>
                      </td>
                      <td style="border-bottom: 1px solid #ccc;">IDR 100.000</td>
                      <td style="border-bottom: 1px solid #ccc; text-align: center">2</td>
                      <td style="border-bottom: 1px solid #ccc; text-align: right; padding-right: 5px">IDR 200.000</td>
                    </tr>
                    <tr>
                      <td style="border-bottom: 1px solid #ccc; padding: 5px">
                        <table border="0" cellspacing="0" cellpadding="0">
                          <tr><td><b>Product Name</b></td></tr>
                          <tr><td>Color</td></tr>
                          <tr><td>Size</td></tr>
                        </table>
                      </td>
                      <td style="border-bottom: 1px solid #ccc;">IDR 100.000</td>
                      <td style="border-bottom: 1px solid #ccc; text-align: center">2</td>
                      <td style="border-bottom: 1px solid #ccc; text-align: right; padding-right: 5px">IDR 200.000</td>
                    </tr>
                  <tbody>
                </table>
              </td>
            </tr>
            <tr>
              <td>
                <table width="540" border="0" cellspacing="0" cellpadding="0" align="center" style="font-size: 11px; line-height: 16px; padding-top: 7px">
                  <tbody>
                    <tr>
                      <td style="padding-left: 280px; padding-bottom: 5px">DISCOUNT</td>
                      <td style="padding-bottom: 5px; padding-right: 5px; text-align: right">0</td>
                    </tr>
                    <tr>
                      <td style="padding-left: 280px; padding-bottom: 5px">SHIPPING FEE</td>
                      <td style="padding-bottom: 5px; padding-right: 5px; text-align: right">IDR 10.000</td>
                    </tr>
                    <tr>
                      <td style="border-top: 1px solid #ccc; padding: 7px 0 5px 280px">TOTAL</td>
                      <td style="border-top: 1px solid #ccc; padding-right: 5px; font-size: 14px; text-align: right"><b>IDR 110.000</b></td>
                    </tr>
                  <tbody>
                </table>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </tbody>
  </table>


  <table width="600" border="0" cellspacing="0" cellpadding="0" align="center" style="font-size:11px; color: #999; margin-top:15px">
    <tbody>
      <tr>
        <td style="padding-left:20px; padding-right:20px">
          © 2013 Website Name. Powered by <a style="color: #666; text-decoration: none" href="http://www.antikode.com">Antikode</a>. <br><br>
        </td>
      </tr>
    </tbody>
  </table>';
  
  	  $subject   = "[".$general['website_title']."] ".$order_number." Order Delivered + Sales Receipt"; 
  	  $headers   = "Content-Type: text/html; charset=ISO-8859-1\r\n".
      $headers  .= "From: ".$general['website_title']." <" .$info['email']. ">\r\n"; //optional headerfields
  
      mail($recipient, $subject, $mail_body, $headers);
	  }
		 
         $_SESSION['alert'] = "success";
	     $_SESSION['msg']   = "Success deliver item(s). An email has been sent to : ".$detail['user_email'];
	  }else{
         $_SESSION['alert'] = "success";
	     $_SESSION['msg']   = "Success deliver item(s).";
	  }
	  
   }
   
}

// Submit handler
if(isset($_POST['btn-order-detail'])){

   if($_POST['btn-order-detail'] == "Mark as Paid"){
      db_update_mark_as_paid($order_detail['order_id']);
   }else if($_POST['btn-order-detail'] == "Save Changes"){

	  $one   = $_POST['order_confirm_bank'];
	  $two   = $_POST['order_confirm_name'];
	  $three = $_POST['backup_order_confirm_amount'];
	  $four  = $order_detail['order_id'];
	  
	  $ten    = $_POST['item_quantity'];
	  $eleven = $_POST['item_id_quantity'];
	  
	  update_order_detail_1($one,$two,$three,$four);
	  update_order_detail_2($ten,$eleven);
   }

}


// Get payment_status
$flag_payment_status = control_get_payment_status($order_detail['payment_status']);

// Get fulfillment_status
$flag_fulfillment_status = control_fulfillment_status($order_detail['fulfillment_status']);

$flag_paid = $detail['order_confirm_amount'] - $detail['order_total_amount'];

function flag_paid($total, $confirm){
   $flag_paid = $confirm - $total;
   
   if($flag_paid > 0){
      $print = "<p class=\"field-message error\">Underpaid IDR : ".number_format($flag_paid,0,',','.')."</p>";
   }else{
      $print = "<p class=\"field-message success\">Overpaid IDR : ".number_format($flag_paid,0,',','.')."</p>";
   }
   
   echo $print;
   
}

function get_price($post_promo_id, $post_promo_value, $post_was_price){
   
   if($post_promo_id == 1){
      $now_price = $post_was_price - (($post_promo_value / 100) * $post_was_price);
   }else{
      $now_price = $post_was_price - $post_promo_value;
   }
   
   return $now_price;
   
}
?>