<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
    	<?php $prefix="../../";?>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Admin Demo</title>
        <meta name="description" content="Antikode Admin Demo">
        <meta name="format-detection" content="telephone=no">
		<!--[if lt IE 9]>
			<script src="<?php echo $prefix;?>js/html5shiv.js"></script>
		<![endif]-->
        <link rel="stylesheet" href="<?php echo $prefix;?>css/normalize.css">
        <link rel="stylesheet" href="<?php echo $prefix;?>css/main.css">
        <script src="<?php echo $prefix;?>script/vendor/modernizr-2.6.1.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an outdated browser. <a href="http://browsehappy.com/">Upgrade your browser today</a> or <a href="http://www.google.com/chromeframe/?redirect=true">install Google Chrome Frame</a> to better experience this site.</p>
        <![endif]-->


        <div class="hidden">
            <div class="overlay over-cancel">
                <div class="header">
                        <h2>Change Order / Cancel Order</h2> 
                    </div>
                <div class="content">
                    <ul class="field-set-stacked">
                        <li class="field">
                            <label for="xxxx" class="hidden">Reason</label>
                            <select class="input-select">
                                <option>Change order</option>
                                <option>Cancel order</option>
                            </select>
                        </li>
                        <li class="field">
                            <label for="xxxx">Reason of order cancellation</label>
                            <select class="input-select">
                                <option>Customer cancelled order</option>
                            </select>
                        </li>
                        <li class="field field-checkbox">
                            <label for="xxxx">Refund</label>
                            <input checked type="checkbox" class="input-checkbox" id="xxxx" name="xxxx" value="y">
                        </li>
                        <li class="field field-checkbox">
                            <label for="xxxx">Restock inventory</label>
                            <input checked type="checkbox" class="input-checkbox" id="xxxx" name="xxxx" value="y">
                        </li>
                        <li class="field field-checkbox">
                            <label for="xxxx">Notify customer about the cancellation</label>
                            <input checked type="checkbox" class="input-checkbox" id="xxxx" name="xxxx" value="y">
                        </li>
                    </ul>
                </div>
            </div>
            <div class="overlay_bg70"></div>
        </div>

        <div id="container">

            <?php include($prefix."static/header.php");?>

            <?php include($prefix."static/breadcrumbs.php");?>

            <div class="sub-header clearfix">
                <div class="content">
                    <h2>Order # <span class="info">MON0101001</span></h2>
                    <div class="btn-placeholder">
                        <input type="button" class="btn grey main" value="Add Notes">
                        <input type="button" class="btn grey main" value="Print">
                        <input type="button" class="btn orange main" value="Edit Order">
                        <input type="button" class="btn red main" value="Cancel Order">
                    </div>
                </div>
            </div>

            <div class="info-header hidden">
                <div class="content">
                    Edit Order Mode
                </div>
            </div>

            <div id="main-content">

                <div class="clearfix">

                    <div class="box clearfix fr" style="width: 30%; height: 230px">
                        <div class="content" style="margin-left: 0; width: 232px">
                            <ul class="field-set">
                                <li class="field clearfix" style="border-bottom: 1px solid #eee; margin-bottom: 15px; padding-bottom: 8px">
                                    <h3><a href="">John Doe</a></h3>
                                    <p style="color: #999; padding-top: 0"><a href="mailto:info@antikode.com">info@antikode.com</a></p>
                                    <p style="color: #999; padding-top: 0">Member</p>
                                </li>
                                <li class="field">
                                    <label for="page-description" style="width: 50px; color: #999">Ship to</label>
                                    <p class="">Address 1</p>
                                    <!--<select type="text" class="input-select" style="width: 182px">
                                        <option>Address 1</option>
                                    </select>-->
                                </li>
                                <li>
                                    Jl. Jurang Mangu No. 8<br>
                                    Bintaro Jaya<br>
                                    Tangerang Selatan<br>
                                    Banten<br>
                                    Indonesia
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="box clearfix fl" style="width:640px; height: 230px">
                        <div class="desc">
                            <h3>Payment</h3>
                            <p>Payment status:</p>
                            <div class="stat yellow" style="margin-top: 10px">Confirmed</div>
                        </div>
                        <div class="content" style="width: 400px">
                            <div class="btn-placeholder" style="position: absolute; top: 20px; right: 15px; z-index:2;">
                                <input type="button" class="btn green main" value="Mark as Paid">
                            </div>
                            <ul class="field-set">
                                <li class="field clearfix" style="border-bottom: 1px solid #eee; margin-bottom: 15px; padding-bottom: 20px">
                                    <label style="width: 120px">Amount Due</label>
                                    <p><b>IDR 600.000</b></p>
                                </li>
                                <li class="field">
                                    <label  style="width: 120px">Payment method</label>
                                    <p class="">Bank Transfer via BCA</p>
                                    <select type="text" class="hidden input-select" style="width: 280px">
                                        <option>Bank Transfer via BCA</option>
                                    </select>
                                </li>
                                <li class="field clearfix">
                                    <label for="url-handle" style="width: 120px">Account name</label>
                                    <p>Nicholas</p>
                                    <input type="text" class="hidden input-text url" value="Nicholas" style="width: 280px">
                                </li>
                                <li class="field clearfix">
                                    <label style="width: 120px">Amount</label>
                                    <p class="" style="color: #cf4f4f">IDR 500.000</p>
                                    <input type="text" class="hidden input-text url" value="IDR 500.000" style="width: 280px">
                                </li>
                                
                            </ul>
                        </div>
                    </div>

                </div>

                <div class="box clearfix">
                    <div class="desc">
                        <h3>Fulfillment</h3>
                        <p>Fulfillment status:</p>
                        <div class="stat yellow" style="margin-top: 10px">Partial</div>
                    </div>
                    <div class="content">
                        <div class="btn-placeholder" style="position: absolute; top: 20px; right: 20px; z-index:2;">
                            <input type="button" class="btn green main" value="Deliver 2 Items">
                        </div>
                        <ul class="field-set">
                            <li class="field clearfix" style="border-bottom: 1px solid #eee; padding-bottom: 20px; margin-bottom: 15px">
                                <label for="url-handle">Shipping preference</label>
                                <p>JNE Regular</p>
                                <!--<select type="text" class="input-select">
                                    <option>JNE Regular</option>
                                    <option>JNE Express</option>
                                </select>-->
                            </li>
                        </ul>
                        <form action="" method="POST">
                            <table cellpadding="0" cellspacing="0" class="basket">
                                <thead>
                                    <tr>
                                        <th class="extrasmall"></th>
                                        <th class="large">Item(s)</th>
                                        <th class="medium">Price</th>
                                        <th class="small">Qty.</th>
                                        <th class="medium">Total</th>
                                        <th class="small"></th>
                                    </tr>
                                </thead>
                                <tbody class="basket-data">
                                    <tr class="delivered">
                                        <td><input type="checkbox" checked disabled></td>
                                        <td class="large">
                                            <img src="<?php echo $prefix;?>files/common/sample_product.jpg" width="80" height="120">
                                            <div class="data">
                                                <div class="name"><a href="">Bitch Please Tee</a></div>
                                                <div class="attribute">Blue</div>
                                                <div class="attribute">XS</div>
                                                <div class="courier">
                                                    <b>JNE</b> 
                                                    #123123123123<br>
                                                    on Fri, 30 Mar 2013
                                                </div>
                                            </div>
                                        </td>
                                        <td class="medium">
                                            <p class="currency">IDR</p>
                                            <p class="amount">100.000</p>
                                        </td>
                                        <td class="small">
                                            <div class="outer-center">
                                                <div class="inner-center">
                                                    <input type="text" class="input-text basket-qty" value="1">

                                                </div>
                                            </div>
                                        </td>
                                        <td class="medium">
                                            <p class="currency">IDR</p>
                                            <p class="amount">200.000</p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><input type="checkbox" checked></td>
                                        <td class="large">
                                            <img src="<?php echo $prefix;?>files/common/sample_product.jpg" width="80" height="120">
                                            <div class="data">
                                                <div class="name"><a href="">Rabbit Trick Long Tail Top</a></div>
                                                <div class="attribute">Black</div>
                                            </div>
                                        </td>
                                        <td class="medium">
                                            <p class="currency">IDR</p>
                                            <p class="amount">100.000</p>
                                        </td>
                                        <td class="small">
                                            <div class="outer-center">
                                                <div class="inner-center">
                                                    <input type="text" class="input-text basket-qty" value="1">

                                                </div>
                                            </div>
                                        </td>
                                        <td class="medium">
                                            <p class="currency">IDR</p>
                                            <p class="amount">200.000</p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><input type="checkbox" checked></td>
                                        <td class="large">
                                            <img src="<?php echo $prefix;?>files/common/sample_product.jpg" width="80" height="120">
                                            <div class="data">
                                                <div class="name"><a href="">Product Name</a></div>
                                                <div class="attribute">Attribute 1</div>
                                            </div>
                                        </td>
                                        <td class="medium">
                                            <p class="currency">IDR</p>
                                            <p class="amount">100.000</p>
                                        </td>
                                        <td class="small">
                                            <div class="outer-center">
                                                <div class="inner-center">
                                                    <input type="text" class="input-text basket-qty" value="1">

                                                </div>
                                            </div>
                                        </td>
                                        <td class="medium">
                                            <p class="currency">IDR</p>
                                            <p class="amount">200.000</p>
                                        </td>
                                    </tr>
                                </tbody>
                            </table><!--basket-->
                            <div class="basket-totals" style="border-bottom: 1px solid #ddd">
                                <div class="row clearfix">
                                    <div class="title">Subtotal</div>
                                    <div class="content">
                                        <p class="currency">IDR</p>
                                        <p class="amount">600.000</p>
                                    </div>
                                </div>
                                <div class="row clearfix">
                                    <div class="title">Discount</div>
                                    <div class="content">
                                        <p class="currency">IDR</p>
                                        <p class="amount">-30.000</p>
                                    </div>
                                </div>
                                <div class="row clearfix">
                                    <div class="title">Shipping</div>
                                    <div class="content">
                                        <p class="currency">IDR</p>
                                        <p class="amount">5.000</p>
                                    </div>
                                </div>
                                <div class="row clearfix">
                                    <div class="title">Total</div>
                                    <div class="content">
                                        <p class="currency">IDR</p>
                                        <p class="amount"><b>575.000</b></p>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div><!--box-->

            </div><!--main-content-->

            <?php include($prefix."static/footer.php");?>

        </div> <!--container-->

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="script/vendor/jquery-1.8.0.min.js"><\/script>')</script>
        <script src="<?php echo $prefix;?>script/plugins.js"></script>
        <script src="<?php echo $prefix;?>script/main.js"></script>

    </body>
</html>
