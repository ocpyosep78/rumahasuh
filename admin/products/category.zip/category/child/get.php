<?php
/* -- FUNCTION -- */
function count_category($post_relation_level, $post_parent_id, $search, $sort_by, $qpp){
   $conn  = connDB();
   
   $sql   = "SELECT * FROM tbl_category AS cat INNER JOIN tbl_category_relation AS rel ON cat.category_id = rel.category_child
			 WHERE $search  AND `category_parent` != 'top' AND `category_parent` = '$post_parent_id' AND `relation_level` = '$post_relation_level'
			 GROUP BY category_id
			 ORDER BY $sort_by 
			";
   $query = mysql_query($sql, $conn);
   
   $full_order['total_query'] = mysql_num_rows($query);
   $full_order['total_page']  = ceil($full_order['total_query'] / $qpp); 

   return $full_order;
}


function get_categories($post_relation_level, $post_parent_id, $search, $sort_by, $first_record, $qpp){
   $conn  = connDB();
   
   $sql   = "SELECT * FROM tbl_category AS cat INNER JOIN tbl_category_relation AS rel ON cat.category_id = rel.category_child
			 WHERE $search  AND `category_parent` != 'top' AND `category_parent` = '$post_parent_id' AND `relation_level` = '$post_relation_level'
			 GROUP BY category_id
			 ORDER BY $sort_by 
			 LIMIT  $first_record, $qpp
			";
   $query = mysql_query($sql, $conn);
   $row   = array();
   
   while($result = mysql_fetch_array($query)){
      array_push($row, $result);
   }
   
   return $row;
}


function count_products($post_product_category){
   $conn   = connDB();
   
   $sql    = "SELECT COUNT(*) AS rows FROM tbl_product WHERE `product_category`  = '$post_product_category'";
   $query  = mysql_query($sql, $conn);
   $result = mysql_fetch_array($query);
   
   return $result;
}


function get_parent($post_category_id){
   $conn   = connDB();
   
   $sql    = "SELECT * FROM tbl_category WHERE `category_id`  = '$post_category_id'";
   $query  = mysql_query($sql, $conn);
   $result = mysql_fetch_array($query);
   
   return $result;
}
?>